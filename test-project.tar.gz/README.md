hi sam
